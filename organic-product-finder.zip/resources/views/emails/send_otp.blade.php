<p>Your OTP is: {{ $otp }}</p>
<p>This OTP will expire in 5 minutes</p> 